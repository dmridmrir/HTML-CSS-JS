function over(obj){
	obj.src="media/banana.jpg"
}
function out(obj){
	obj.src="media/apple.jpg"
}